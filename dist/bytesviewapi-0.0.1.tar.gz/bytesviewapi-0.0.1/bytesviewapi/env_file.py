# All the API URL and language suported by API.


SENTIMENT_URL = 'http://api.bytesview.com/1/static/sentiment'


sentiment_languages_support = {"ar", "en"}